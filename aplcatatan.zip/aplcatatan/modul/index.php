<?php 
	session_start();
	if (!isset($_SESSION['nama'])) {
		include"../index.php";
	}else{
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title>Selamat Datang <?=$_SESSION['nama']?></title>
		</head>
		<body>
			<h1>Tampilan untuk pengguna yang sudah login</h1>
			<h2><?=$_SESSION['nama']?></h2>
			<a href="logout.php">Keluar</a>		
		</body>
		</html>
		<?php
	}

 ?>