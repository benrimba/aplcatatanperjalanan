<?php 
	session_start();
	$_SESSION['nama'];
	session_destroy();
	header('location:../index.php');
 ?>