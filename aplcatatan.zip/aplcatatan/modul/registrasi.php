<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Registrasi</title>
</head>
<body>
	<form action="" method="POST">
		<label>NIK</label>
		<input type="text" name="nik"></br>
		<label>Nama Lengkap</label>
		<input type="text" name="nm"></br>
		<button type="submit" name="btn">Registrasi</button>
	</form>
	<?php 
		if (isset($_POST['btn'])) {
			$nik  = $_POST['nik'];
			$nama = $_POST['nm'];
			$arrayData = array($nik,$nama);
			$fp = fopen('nik.csv','a+');
			$input = fputcsv($fp,$arrayData);
			if ($input) {
				echo"<h3>Data berhasil di input</h3>";
			}else{
				echo"<h3>Data gagal input</h3>";
			}
			echo"<a href='output.php'>Lihat Data</a>";
		}
	 ?>
</body>
</html>