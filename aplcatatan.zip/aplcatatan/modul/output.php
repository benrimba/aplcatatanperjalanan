<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Data Pengunjung</title>
</head>
<body>
	<table width="100%" border="1">
		<thead>
			<tr>
				<th>No</th>
				<th>NIK</th>
				<th>Nama</th>
			</tr>
		</thead>
		<tbody>
			<?php
				if (($handle = fopen('nik.csv','r'))!== FALSE) {
					$row = 1;
					while (($data =  fgetcsv($handle,1000,",")) !== FALSE) {
						echo "<tr>";
						echo "<td>".$row++."</td>";
						echo "<td>".$data[0]."</td>";
						echo "<td>".$data[1]."</td>";
						echo"</tr>";
					}
				}else{
					echo"Error";
				}

			 ?>			
		</tbody>
  </table>
  <a href="registrasi.php">Registrasi</a>
</body>
</html>