<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Aplikasi Catatan Perjalanan</title>
</head>
<body>
	<form action="" method="POST">
		<label>NIK</label>
		<input type="text" name="nik"></br>
		<label>Nama Lengkap</label>
		<input type="text" name="nm"></br>
		<a href="modul/registrasi.php">Registrasi</a>
		<button type="submit" name="btn">Login</button>
	</form>
	<?php 
		if (isset($_POST['btn'])) {			
			$user = trim($_POST['nik']);
			$pass = trim($_POST['nm']);
			if (!strlen($user) || !strlen($pass)) {
				die("Silahkan masukan username dan password");
			}
			$sukses = false;
			$handle = fopen("modul/nik.csv","r");
			while (($data = fgetcsv($handle)) !==false) {
				if ($data[0]==$user && $data[1]==$pass) {
					$sukses = true;
					break;
				}
			}
			fclose($handle);
			if ($sukses) {
				session_start();
				$_SESSION['nama']=$data[1];
				header('location:modul/index.php');
			}else{
				echo"Gagal";
			}
		}
	 ?>
</body>
</html>